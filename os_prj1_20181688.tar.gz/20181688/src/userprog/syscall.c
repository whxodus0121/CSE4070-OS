#include "userprog/syscall.h"
#include "console.h"
#include "devices/input.h"
#include "devices/shutdown.h"
#include "filesys/file.h"
#include "filesys/inode.h"
#include "process.h"
#include "threads/interrupt.h"
#include "threads/synch.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <syscall-nr.h>
static void syscall_handler(struct intr_frame *);
void syscall_init(void);

// utils
void check_address(uint32_t *esp, int n);
void init(int *syscall_arg_num, int (*fp[100])(uint32_t *));

// System calls
int halt(uint32_t *esp);
int exit(uint32_t *esp);
int exec(uint32_t *esp);
int wait(uint32_t *esp);
int write(uint32_t *esp);
int read(uint32_t *esp);

int max_of_four_int(uint32_t *esp);
int fibonacci(uint32_t *esp);

void init(int *argnum, int (*fn[100])(uint32_t *))
{
	fn[SYS_HALT] = halt;
	argnum[SYS_HALT] = 0;
    fn[SYS_EXIT] = exit;
    argnum[SYS_EXIT] = 1;
    fn[SYS_EXEC] = exec;
    argnum[SYS_EXEC] = 1;
    fn[SYS_WAIT] = wait;
    argnum[SYS_WAIT] = 1;
    fn[SYS_WRITE] = write;
    argnum[SYS_WRITE] = 3;
	fn[SYS_READ] = read;
	argnum[SYS_READ] = 3;
    fn[SYS_FIBO] = fibonacci;
    argnum[SYS_FIBO] = 1;
    fn[SYS_MAX_FOUR_INT] = max_of_four_int;
    argnum[SYS_MAX_FOUR_INT] = 4;
}

/*
    Check vaddr is user vaddr ( esp ~ esp + 4 * n )
*/
void check_address(uint32_t *esp, int n)
{
    int i;
    for (i = 0; i <= n; ++i)
    {
        if (!is_user_vaddr((void *)(esp + 4 * i)))
        {
            exit(-1);
        }
    }
}

static void syscall_handler(struct intr_frame *f)
{
    int argnum[100] = {0,};

    int (*fn[100])(uint32_t *);

    init(argnum, fn);

    uint32_t *esp = (uint32_t *)f->esp;

    check_address(esp,argnum[*esp]);

    if (*esp == SYS_HALT || *esp == SYS_EXIT)
    {
        fn[*esp](esp);
    }
    else 
    {
        f->eax = fn[*esp](esp);
    }
}

void syscall_init(void)
{
    intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}

int halt(uint32_t *esp)
{
    shutdown_power_off();
    return 0;
}

int exit(uint32_t *esp)
{
    int status = -1;
    if (esp != -1)
    {
        status = (int)esp[1];
    }
    int i;
    char thread[256];
    for (i = 0; i < strlen(thread_name()) + 1; ++i)
    {
        if (thread_name()[i] == ' ')
        {
            break;
        }
    }
    strlcpy(thread, thread_name(), i + 1);

    printf("%s: exit(%d)\n", thread, status);

    thread_current()->exit_status = status;
    thread_exit();
    return 0;
}

int wait(uint32_t *esp)
{
    return process_wait((int)esp[1]);
}

int exec(uint32_t *esp)
{
    return process_execute((char *)esp[1]);
}

int write(uint32_t *esp)
{
    int fd = (int)esp[1];
    void *buffer = (void *)esp[2];
    unsigned size = (int)esp[3];
    if (fd == 1)
    {
        putbuf(buffer, size);
        return size;
    }
    return -1;
}

int read(uint32_t *esp)
{
    int fd = (int)esp[1];
    void *buffer = (void *)esp[2];
    unsigned size = (int)esp[3];

    if (fd == 0)
    {
        for (int i = 0; i <= size; ++i){

			if(input_getc()==NULL){
				
				break;
			}
        }
        return size;
    }

    return -1;
}

int fibonacci(uint32_t *esp)
{
    int n = (int)esp[1];
    int i;
    int fn_2 = 0;
    int fn_1 = 1;
    int fn = 0;
    for (i = 0; i < n; ++i)
    {
        fn = fn_2 + fn_1;
        fn_2 = fn_1;
        fn_1 = fn;
    }
    return fn_2;
}

int max_of_four_int(uint32_t *esp)
{
    int i;
    int max = 0;
    for (i = 1; i <= 4; ++i)
    {
        if (max < (int)esp[i])
        {
            max = (int)esp[i];
        }
    }
    return max;
}
